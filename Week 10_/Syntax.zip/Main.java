
class Main
class time
{
  public static void main(String[]args) {      
    Scanner scan = new Scanner(System.in);
    String time = scan.next();
    
    //splitting the string in two parts when we encounter ":" in the string
    String tArr[] = time.split(":");
    String AmPm = tArr[2].substring(2,4);
    int hh,mm,ss;

    //converting the strings to integers
    hh = Integer.parseInt(tArr[0]);
    mm = Integer.parseInt(tArr[1]);

    String checkPM = "PM",checkAM ="AM";
       
    if(AmPm.equals(checkAM) && hh==12)
    {
        hh=0;
    }
    else if(AmPm.equals(checkPM)&& hh<12)
    {
        hh+=12;
    }
        
    System.out.printf("%02d:%02d",hh,mm);
  }
}